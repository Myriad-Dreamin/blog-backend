<?php

namespace Symfony\Component\Debug\Tests\Fixtures2;

class RequiredTwice
{
}
