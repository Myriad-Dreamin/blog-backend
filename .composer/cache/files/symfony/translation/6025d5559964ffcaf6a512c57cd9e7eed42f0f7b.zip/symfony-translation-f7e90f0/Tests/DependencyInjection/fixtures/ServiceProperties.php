<?php

namespace Symfony\Component\Translation\Tests\DependencyInjection\fixtures;

class ServiceProperties
{
    public $translator;
}
